package com.example.studystudy;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentMainEducation extends Fragment {

    private ListView listViewSeansons;
    private ImageView imageViewUserPhoto;
    private TextView  textViewStudentName;
    private TextView  textViewFaculityName;
    private TextView  textViewStudentGroup;

    public FragmentMainEducation() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_fragment_main_education, container, false);
        listViewSeansons = view.findViewById(R.id.listViewSeasons);
        imageViewUserPhoto = view.findViewById(R.id.imageViewUserPhoto);
        textViewStudentName = view.findViewById(R.id.textViewStudentName);
        textViewFaculityName = view.findViewById(R.id.textViewFaculityName);
        textViewStudentGroup = view.findViewById(R.id.textViewStudentGroup);

        //listViewSeansons.setOnItemClickListener()

        return view;
    }

}
