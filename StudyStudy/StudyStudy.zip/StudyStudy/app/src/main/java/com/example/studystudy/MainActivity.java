package com.example.studystudy;

import android.support.design.widget.TabItem;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;

public class MainActivity extends AppCompatActivity {

    private Toolbar mToolbar;
    private TabLayout mTablayout;
    private TabItem TabItemMyNews;
    private TabItem TabItemMyChats;
    private TabItem TabItemMyAccount;
    private ViewPager ViewPagerMyPager;
    private PageController mPageController;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mToolbar = findViewById(R.id.toolBar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setTitle("StudyStudy");

        mTablayout = findViewById(R.id.tabLayout);
        TabItemMyNews = findViewById(R.id.tabItemNews);
        TabItemMyChats = findViewById(R.id.tabItemChats);
        TabItemMyAccount = findViewById(R.id.tabItemMyaccount);
        ViewPagerMyPager = findViewById(R.id.viewPager);

        mPageController = new PageController(getSupportFragmentManager(), mTablayout.getTabCount());
        ViewPagerMyPager.setAdapter(mPageController);

        mTablayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                ViewPagerMyPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        ViewPagerMyPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(mTablayout));


    }
}
