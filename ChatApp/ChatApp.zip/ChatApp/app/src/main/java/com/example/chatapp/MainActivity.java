package com.example.chatapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerViewMessages;
    private MessagesAdapter adapter;

    private EditText editTextmessage;
    private ImageView imageViewSendmessage;

    private List<Message> messages;
    private String author;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerViewMessages = findViewById(R.id.recyclerViewMessages);
        editTextmessage = findViewById(R.id.editTextMessage);
        imageViewSendmessage = findViewById(R.id.imageViewSendMessage);
        adapter = new MessagesAdapter();
        recyclerViewMessages.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewMessages.setAdapter(adapter);
        messages = new ArrayList<>();
        author = "Author";
        imageViewSendmessage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendMessage();
            }
        });
    }

    private void sendMessage(){
        String textOfMessage = editTextmessage.getText().toString().trim();
        if (!textOfMessage.isEmpty()){
            messages.add(new Message(author, textOfMessage));
            adapter.setMessages(messages);
            editTextmessage.setText("");
            recyclerViewMessages.scrollToPosition(adapter.getItemCount()-1);
        }
    }
}
